Current Firmware Version: v0.2.4




