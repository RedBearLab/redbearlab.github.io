#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint32_t HAL_WLAN_SetNetWatchDog(uint32_t timeOutInuS);

#ifdef __cplusplus
}
#endif
