# Duo Firmware

## Current Version

0.2.3-rc.2



