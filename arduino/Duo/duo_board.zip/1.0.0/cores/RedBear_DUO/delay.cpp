
#include "spark_wiring.h"
#include "delay.h"


void delayMode(uint8_t lastMode)
{
	if(lastMode == 1)
	{
		delay(1000);
	}
	else if(lastMode == 2)
	{
		delay(500);
	}
	else if(lastMode == 3)
	{
		delay(100);
	}
}

