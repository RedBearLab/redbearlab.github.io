
#ifndef DELAY_H_
#define DELAY_H_

#include <string.h>
#include <stdint.h>


void delayMode(uint8_t lastMode);


#endif
