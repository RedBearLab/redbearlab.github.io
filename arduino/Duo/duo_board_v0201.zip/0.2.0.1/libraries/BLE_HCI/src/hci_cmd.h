
#ifndef HCI_CMD_
#define HCI_CMD_


#define HCI_COMMAND_DATA_PACKET   0x01
#define HCI_ACL_DATA_PACKET       0x02
#define HCI_SCO_DATA_PACKET       0x03
#define HCI_EVENT_PACKET          0x04



#endif
