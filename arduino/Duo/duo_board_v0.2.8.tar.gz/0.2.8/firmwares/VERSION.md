# Duo Firmware

## Current Version

0.2.4-rc.2



