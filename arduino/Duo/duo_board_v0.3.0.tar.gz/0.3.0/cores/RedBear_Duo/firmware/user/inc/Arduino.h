
#ifndef ARDUINO_H
#define	ARDUINO_H

#include "Particle.h"

#endif	/* ARDUINO_H */

