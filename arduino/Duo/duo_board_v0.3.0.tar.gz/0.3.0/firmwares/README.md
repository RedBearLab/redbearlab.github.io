Current Firmware Version: v0.3.0




