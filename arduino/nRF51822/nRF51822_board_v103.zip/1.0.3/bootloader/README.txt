
nRF51822 Bootloader
—--

This bootloader built with S130 SoftDevice and has OTA feature.

